

$(document).ready(function () {

    $('#nav ul li a').click(function () {
        $('#nav ul li a').removeClass('active');
        $(this).addClass('active');
    })

    $('#burger-menu').click(function () {
        $('#mySidenav').css({
            "width": "250px",
            "transform": "translateX(100px)",
        });

        setInterval(
            function () {
                $('#mySidenav').css({
                    "transform": "translateX(0px)",
                });
                $('#mySidenav a').addClass('animate__animated animate__heartBeat animate__delay-1s');
            },
            3000
        );

    })

    $('.closebtn').click(function () {
        $('#mySidenav').css({
            "width": "0",
            "transform": "translateX(0px)",
        });
        $('#mySidenav').removeClass('animate__animated animate__heartBeat animate__delay-1s');
    })


    // $(".wb, .wd, .dm, .sp").hover(function () {

    //     var div = $(this);
    //     var h1 = $(this).find('h1');
    //     var p = $(this).find('p');

    //     h1.css({
    //         "font-size": "50px"
    //     });

    //     setTimeout(function () {
    //         div.css({
    //             "background-color": "rgb(153, 95, 50)",
    //             "transition": "4.70s",
    //             "transform": "rotate(360deg)"
    //         })
    //         h1.hide();
    //         p.css({
    //             "display": "block"
    //         })

    //     }, 250);

    // }, function () {

    //     var div = $(this);
    //     var h1 = $(this).find('h1');
    //     var p = $(this).find('p');


    //     div.css({
    //         "transform": "rotate(0deg)",
    //         "background-color": "rgb(17, 63, 65)"
    //     })

    //     h1.css({
    //         "font-size": "20px"
    //     });

    //     p.css({
    //         "display": "none"
    //     })

    //     h1.show();

    // });


    $(".wb, .wd, .dm, .sp").hover(function () {

        var div = $(this);
        var h1 = $(this).find('h1');
        var p = $(this).find('p');

        h1.hide();
        p.css({ "display": "block" })
        div.css({ "background-color": "#CB6CE6" })

    }, function () {

        var div = $(this);
        var h1 = $(this).find('h1');
        var p = $(this).find('p');


        div.css({ "background-color": "rgb(0, 0, 0)" })
        p.css({ "display": "none" })
        h1.show();

    });



});